Version - 1.1.1b for OptiFine
This resourcepack made by CatFromNet

Project links:
    Modrinth → https://modrinth.com/resourcepack/rethoughted-trident
    CurseForge → https://www.curseforge.com/minecraft/texture-packs/rethoughted-trident

Feedback and social:
    Author`s discord → @catfromnet
    Discord server → https://discord.gg/q29y59SWEu
